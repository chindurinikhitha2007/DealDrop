export function timeLeft(timestamp, serverOffset = 0) {
  const remaining = Math.max(0, Number(timestamp) - (Date.now() + serverOffset));
  const hours = Math.floor(remaining / 3600000);
  const minutes = Math.floor((remaining % 3600000) / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  return hours
    ? `${hours}h ${String(minutes).padStart(2, '0')}m left`
    : `${minutes}m ${String(seconds).padStart(2, '0')}s left`;
}
