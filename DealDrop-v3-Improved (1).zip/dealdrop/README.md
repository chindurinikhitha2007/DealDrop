# DealDrop — Nearby Deals (v3.0)

DealDrop is a hyperlocal coupon and flash-deal portal for shoppers and neighborhood merchants. This version upgrades the original project while preserving its discovery page, categories, radius/search filters, live expiry countdowns, voucher claims, QR-style voucher display, map, and merchant studio.

## What's improved in v3.0

- **Paginated deal API:** `/api/deals` supports `page`, `limit` (maximum 50), `category`, and `search`; responses include total counts and next-page metadata.
- **API documentation endpoint:** `/api/docs` returns an OpenAPI 3.0.3 document describing available routes and query parameters.
- **Safer API input handling:** bounded search input, clamped pagination values, and a clear response for malformed JSON.

## Existing features

### Shopper experience
- Responsive deal discovery page with category, text-search, and distance filters.
- Live countdowns based on server time.
- Claimable voucher codes with copy/share actions.
- Saved claim history and expired-voucher status.
- Map view for sample neighborhood businesses.

### Merchant experience
- Create and publish limited-quota offers.
- Happy-hour demo toggle.
- Merchant metrics for views, claims, walk-ins, and active deals.

### Engineering upgrades in this version
- **SQLite persistence:** deals and claims are stored in `data/dealdrop.sqlite`; the database uses WAL mode and indexes.
- **Asynchronous database access:** server database operations use the `sqlite3` callback API wrapped in Promises rather than synchronous JSON file reads/writes.
- **Safer claim handling:** voucher allocation and quota updates run inside a transaction; expired held vouchers are returned to the available quota.
- **Input validation:** server validates business name, title, category, quota, and duration.
- **Security headers and rate limiting:** Helmet headers, a JSON request-size limit, and API write-request throttling.
- **Modular frontend:** API helpers and countdown logic are separate modules.
- **Typed API data:** `src/client/api.ts` defines `Deal`, `Claim`, and response types and provides a typed Fetch API wrapper.
- **Automated tests:** Jest tests cover deal validation and voucher quota recovery.
- **Structured logs:** Winston writes JSON logs to the console and `logs/` directory.

## Requirements
- Node.js 18 or newer
- npm

## Run locally

1. Extract the ZIP.
2. Open a terminal in the `dealdrop` folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Compile the TypeScript API helper:

   ```bash
   npm run build
   ```

5. Run the automated tests:

   ```bash
   npm test
   ```

6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser.

The SQLite database is created automatically on first launch and is seeded with sample Hyderabad neighborhood deals. Do not delete `data/dealdrop.sqlite` if you want to keep locally created deals and claims.

## Useful API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Server/database health |
| GET | `/api/deals?page=1&limit=24` | Paginated active deals; optional `category` and `search` filters |
| GET | `/api/docs` | OpenAPI 3.0.3 API description |
| POST | `/api/deals` | Publish a deal |
| POST | `/api/deals/:id/claim` | Claim a voucher |
| POST | `/api/deals/:id/view` | Record a view |
| GET | `/api/claims` | List voucher claims |
| GET | `/api/merchant/summary` | Merchant dashboard metrics |
| POST | `/api/happy-hour` | Toggle sample happy-hour offers |

## Project structure

```text
dealdrop/
├── data/                 # SQLite database is created here
├── lib/
│   ├── dealRules.js      # Validation and quota-recovery rules
│   └── logger.js         # Structured Winston logger
├── logs/                 # Created automatically at runtime
├── public/
│   ├── js/
│   │   ├── api.js        # Browser Fetch API helper (compiled from TypeScript)
│   │   └── countdown.js  # Countdown formatter
│   ├── app.js            # Page interactions and rendering
│   ├── index.html
│   └── style.css
├── src/client/api.ts     # Typed API contracts and Fetch API client
├── tests/dealRules.test.js
├── server.js
├── package.json
└── tsconfig.json
```

## Demo and production notes
- The map and neighborhood distances use sample/demo data; they are not live merchant GPS locations.
- The merchant studio remains a demo and does not include merchant login or role-based access control. Add JWT authentication and merchant ownership checks before real deployment.
- Voucher codes are demo redemption tokens; a real deployment should add authenticated merchant redemption and shopper accounts.
- Before public deployment, configure HTTPS, secrets/environment management, database backups, monitoring, and production-grade authentication/authorization.
