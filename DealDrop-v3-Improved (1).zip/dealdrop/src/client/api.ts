export type DealCategory = 'Dining' | 'Wellness' | 'Fitness' | 'Entertainment' | 'Services';

export interface Deal {
  id: string;
  merchant: string;
  category: DealCategory;
  badge: string;
  title: string;
  shop: string;
  area: string;
  distance: number;
  quota: number;
  remaining: number;
  icon: string;
  accent: string;
  views: number;
  claimed: number;
  createdAt: number;
  expiresAt: number;
  active: boolean | number;
}

export interface Claim {
  id: string;
  dealId: string;
  merchant: string;
  code: string;
  status: 'held' | 'expired' | 'redeemed';
  claimedAt: number;
  claimExpiresAt: number;
}

export interface Pagination { page: number; limit: number; total: number; totalPages: number; hasNext: boolean; }

export interface DealsResponse { serverNow: number; deals: Deal[]; pagination: Pagination; }

export interface ClaimResponse {
  claim: Claim;
  deal: Deal;
  serverNow: number;
}

export async function api<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(url, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data as T;
}

export function escapeHTML(value: unknown): string {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char] as string));
}

export function toast(message: string): void {
  const element = document.querySelector<HTMLElement>('#toast');
  if (!element) return;
  element.textContent = message;
  element.classList.add('show');
  window.setTimeout(() => element.classList.remove('show'), 2300);
}
