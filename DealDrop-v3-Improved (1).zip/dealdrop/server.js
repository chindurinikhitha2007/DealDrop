const express = require('express');
const path = require('path');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const logger = require('./lib/logger');
const { validateDeal } = require('./lib/dealRules');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'dealdrop.sqlite');
const db = new sqlite3.Database(DB_PATH);

const run = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function (error) {
    if (error) reject(error);
    else resolve({ lastID: this.lastID, changes: this.changes });
  });
});
const get = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (error, row) => error ? reject(error) : resolve(row));
});
const all = (sql, params = []) => new Promise((resolve, reject) => {
  db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows));
});

// Keep transactions sequential on this shared SQLite connection.
let transactionQueue = Promise.resolve();
function withTransaction(work) {
  const task = transactionQueue.then(async () => {
    await run('BEGIN IMMEDIATE TRANSACTION');
    try {
      const result = await work();
      await run('COMMIT');
      return result;
    } catch (error) {
      await run('ROLLBACK');
      throw error;
    }
  });
  transactionQueue = task.catch(() => undefined);
  return task;
}

const seedRows = [
  ['Artisan Coffee','Dining','40% OFF','40% off artisan coffee & pastries','Brew District','Kompally',2.4,25,16,'☕','#f3a65b'],
  ['Spice Route Kitchen','Dining','25% OFF','25% off your lunch order','Spice Route','Suchitra',1.8,30,18,'🍛','#ed8064'],
  ['Pizza Corner','Dining','BUY 1 GET 1','Buy one pizza slice, get one free','Pizza Corner','Kompally',3.2,20,13,'🍕','#e87961'],
  ['Green Bowl Cafe','Dining','₹100 OFF','Flat ₹100 off healthy bowls','Green Bowl','Miyapur',4.1,18,10,'🥗','#83b77d'],
  ['Glow Studio','Wellness','25% OFF','25% off salon haircut services','Glow Studio','Suchitra',2.7,20,14,'✂️','#cf8eb5'],
  ['Serenity Spa','Wellness','30% OFF','30% off selected wellness sessions','Serenity Spa','Kompally',4.6,15,10,'🧖','#b99bd8'],
  ['Fresh Face Salon','Wellness','₹150 OFF','Flat ₹150 off your next visit','Fresh Face','Miyapur',1.2,25,15,'💆','#dc9ab4'],
  ['Urban Yoga','Wellness','20% OFF','20% off a beginner yoga session','Urban Yoga','Kompally',2.9,24,13,'🧘','#9bb7a0'],
  ['FitZone Gym','Fitness','1+1 FREE','Bring a friend: 1+1 day pass','FitZone','Suchitra',1.6,25,17,'🏋️','#7e9bd0'],
  ['Pulse Fitness','Fitness','30% OFF','30% off a weekly gym pass','Pulse Fitness','Miyapur',3.8,30,16,'💪','#7da8c8'],
  ['Smash Arena','Entertainment','₹200 OFF','Flat ₹200 off badminton court booking','Smash Arena','Kompally',4.5,12,8,'🏸','#e0a65e'],
  ['Movie Nest','Entertainment','20% OFF','20% off weekday movie tickets','Movie Nest','Suchitra',2.1,40,21,'🎬','#8d8bc9'],
  ['PlayHouse Arcade','Entertainment','15% OFF','15% off arcade game cards','PlayHouse','Miyapur',4.8,35,19,'🕹️','#d49b64'],
  ['QuickClean Dry Cleaners','Services','₹200 OFF','Flat ₹200 off dry cleaning bills','QuickClean','Kompally',1.9,25,15,'👔','#80a8b4'],
  ['Spark Shoe Care','Services','20% OFF','20% off shoe cleaning and care','Spark Shoe Care','Suchitra',3.5,20,11,'👟','#a8a17a'],
  ['FixIt Electronics','Services','10% OFF','10% off accessory and repair services','FixIt','Miyapur',4.9,18,12,'🔧','#8c9ba8']
];

async function initializeDatabase() {
  await run('PRAGMA journal_mode = WAL');
  await run('PRAGMA foreign_keys = ON');
  await run(`CREATE TABLE IF NOT EXISTS deals (
    id TEXT PRIMARY KEY, merchant TEXT NOT NULL, category TEXT NOT NULL, badge TEXT NOT NULL,
    title TEXT NOT NULL, shop TEXT NOT NULL, area TEXT NOT NULL, code TEXT NOT NULL,
    distance REAL NOT NULL DEFAULT 2, quota INTEGER NOT NULL, remaining INTEGER NOT NULL,
    icon TEXT NOT NULL DEFAULT '✨', accent TEXT NOT NULL DEFAULT '#8b7cf6',
    views INTEGER NOT NULL DEFAULT 0, claimed INTEGER NOT NULL DEFAULT 0,
    estimatedWalkins INTEGER NOT NULL DEFAULT 0, createdAt INTEGER NOT NULL,
    expiresAt INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1,
    happyHour INTEGER NOT NULL DEFAULT 0, happyApplied INTEGER NOT NULL DEFAULT 0
  )`);
  await run(`CREATE TABLE IF NOT EXISTS claims (
    id TEXT PRIMARY KEY, dealId TEXT NOT NULL, merchant TEXT NOT NULL, code TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL CHECK(status IN ('held','expired','redeemed')),
    claimedAt INTEGER NOT NULL, claimExpiresAt INTEGER NOT NULL,
    FOREIGN KEY(dealId) REFERENCES deals(id)
  )`);
  await run('CREATE INDEX IF NOT EXISTS idx_deals_active_expiry ON deals(active, expiresAt)');
  await run('CREATE INDEX IF NOT EXISTS idx_claims_status_expiry ON claims(status, claimExpiresAt)');
  const row = await get('SELECT COUNT(*) AS count FROM deals');
  if (row.count === 0) {
    const now = Date.now();
    for (const [i, r] of seedRows.entries()) {
      const [merchant,category,badge,title,shop,area,distance,quota,remaining,icon,accent] = r;
      await run(`INSERT INTO deals
        (id,merchant,category,badge,title,shop,area,code,distance,quota,remaining,icon,accent,views,claimed,estimatedWalkins,createdAt,expiresAt,active)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)`,
        [`deal-${i+1}`,merchant,category,badge,title,shop,area,merchant.replace(/[^A-Z]/gi,'').slice(0,5).toUpperCase()+i,
          distance,quota,remaining,icon,accent,120+i*17,quota-remaining,Math.max(1,Math.round((quota-remaining)*.65)),now,now+(i===0?2:4+i%5)*3600000]);
    }
    logger.info('Seeded sample neighborhood deals', { count: seedRows.length });
  }
}

async function cleanupExpiredClaims() {
  const now = Date.now();
  return withTransaction(async () => {
    const expired = await all("SELECT id, dealId FROM claims WHERE status='held' AND claimExpiresAt <= ?", [now]);
    for (const claim of expired) {
      await run("UPDATE claims SET status='expired' WHERE id=? AND status='held'", [claim.id]);
      await run('UPDATE deals SET remaining=MIN(quota, remaining+1), claimed=MAX(0, claimed-1) WHERE id=?', [claim.dealId]);
    }
    if (expired.length) logger.info('Recovered expired voucher quota', { recovered: expired.length });
    return expired.length;
  });
}

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", 'https://unpkg.com'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://unpkg.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
      imgSrc: ["'self'", 'data:', 'https://*.tile.openstreetmap.org', 'https://unpkg.com'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});
app.use('/api', (req, res, next) => {
  logger.info('API request', { method: req.method, path: req.path });
  next();
});
const writeLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false });
app.use('/api/deals', writeLimiter);
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', async (req, res) => {
  try {
    const row = await get('SELECT COUNT(*) AS deals FROM deals');
    res.json({ status: 'ok', database: 'sqlite', deals: row.deals, timestamp: new Date().toISOString() });
  } catch (error) { res.status(503).json({ status: 'error' }); }
});

app.get('/api/deals', async (req, res, next) => {
  try {
    await cleanupExpiredClaims();
    const now = Date.now();
    const page = Math.max(1, Math.min(10000, Number.parseInt(req.query.page, 10) || 1));
    const limit = Math.max(1, Math.min(50, Number.parseInt(req.query.limit, 10) || 24));
    const offset = (page - 1) * limit;
    const category = String(req.query.category || '').trim();
    const search = String(req.query.search || '').trim().slice(0, 80);
    const filters = ['active=1', 'expiresAt>?'];
    const params = [now];
    if (category && ['Dining','Wellness','Fitness','Entertainment','Services'].includes(category)) {
      filters.push('category=?'); params.push(category);
    }
    if (search) {
      filters.push('(merchant LIKE ? OR title LIKE ? OR area LIKE ?)');
      const term = `%${search.replace(/[\%_]/g, '\$&')}%`;
      params.push(term, term, term);
    }
    const where = filters.join(' AND ');
    const count = await get(`SELECT COUNT(*) AS total FROM deals WHERE ${where}`, params);
    const deals = await all(`SELECT * FROM deals WHERE ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`, [...params, limit, offset]);
    res.json({ serverNow: now, deals, pagination: { page, limit, total: count.total, totalPages: Math.ceil(count.total / limit), hasNext: offset + deals.length < count.total } });
  } catch (error) { next(error); }
});

app.get('/api/docs', (req, res) => {
  res.json({ openapi: '3.0.3', info: { title: 'DealDrop API', version: '3.0.0', description: 'Nearby deals and limited-quota voucher API' },
    servers: [{ url: `${req.protocol}://${req.get('host')}` }], paths: {
      '/api/health': { get: { summary: 'Check server and database health' } },
      '/api/deals': { get: { summary: 'List active deals', parameters: [
        { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1 } },
        { name: 'limit', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 50 } },
        { name: 'category', in: 'query', schema: { type: 'string' } },
        { name: 'search', in: 'query', schema: { type: 'string', maxLength: 80 } }
      ] }, post: { summary: 'Publish a validated deal' } },
      '/api/deals/{id}/claim': { post: { summary: 'Claim one voucher using an atomic transaction' } },
      '/api/deals/{id}/view': { post: { summary: 'Record a deal view' } },
      '/api/claims': { get: { summary: 'List voucher claims' } },
      '/api/merchant/summary': { get: { summary: 'Get merchant dashboard metrics' } },
      '/api/happy-hour': { post: { summary: 'Toggle demo happy-hour offers' } }
    } });
});

app.post('/api/deals/:id/view', async (req, res, next) => {
  try {
    const result = await run('UPDATE deals SET views=views+1 WHERE id=?', [req.params.id]);
    if (!result.changes) return res.status(404).json({ error: 'Deal not found' });
    const row = await get('SELECT views FROM deals WHERE id=?', [req.params.id]);
    res.json(row);
  } catch (error) { next(error); }
});

app.post('/api/deals/:id/claim', async (req, res, next) => {
  try {
    await cleanupExpiredClaims();
    const result = await withTransaction(async () => {
      const deal = await get('SELECT * FROM deals WHERE id=? AND active=1 AND expiresAt>?', [req.params.id, Date.now()]);
      if (!deal) {
        const error = new Error('This deal has expired or is unavailable.');
        error.status = 404;
        throw error;
      }
      if (deal.remaining <= 0) {
        const error = new Error('All vouchers have been claimed.');
        error.status = 409;
        throw error;
      }
      const code = `${deal.code}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const claim = { id: crypto.randomUUID(), dealId: deal.id, merchant: deal.merchant, code, status: 'held',
        claimedAt: Date.now(), claimExpiresAt: Date.now() + 2 * 60 * 60 * 1000 };
      const update = await run('UPDATE deals SET remaining=remaining-1, claimed=claimed+1 WHERE id=? AND remaining>0', [deal.id]);
      if (!update.changes) {
        const error = new Error('All vouchers have been claimed.');
        error.status = 409;
        throw error;
      }
      await run('INSERT INTO claims (id,dealId,merchant,code,status,claimedAt,claimExpiresAt) VALUES (?,?,?,?,?,?,?)',
        [claim.id,claim.dealId,claim.merchant,claim.code,claim.status,claim.claimedAt,claim.claimExpiresAt]);
      const updatedDeal = await get('SELECT * FROM deals WHERE id=?', [deal.id]);
      return { claim, deal: updatedDeal, serverNow: Date.now() };
    });
    res.status(201).json(result);
  } catch (error) {
    if (error.status) return res.status(error.status).json({ error: error.message });
    next(error);
  }
});

app.post('/api/deals', async (req, res, next) => {
  try {
    const input = req.body || {};
    const validation = validateDeal(input);
    if (!validation.valid) return res.status(400).json({ error: validation.errors.join(' ') });
    const merchant = String(input.merchant).trim();
    const title = String(input.title).trim();
    const category = String(input.category).trim();
    const badge = String(input.badge || 'SPECIAL OFFER').trim().slice(0, 30);
    const area = String(input.area || 'Kompally').trim().slice(0, 50);
    const id = `deal-${crypto.randomUUID()}`;
    const code = (merchant.replace(/[^A-Z]/gi,'').slice(0,5).toUpperCase() || 'DEAL') + crypto.randomInt(10, 99);
    const icon = ({Dining:'☕',Wellness:'✂️',Fitness:'🏋️',Entertainment:'🎬',Services:'🛠️'})[category] || '✨';
    const createdAt = Date.now();
    const deal = { id, merchant, category, badge, title, shop: merchant, area, code, distance: 2,
      quota: Number(input.quota), remaining: Number(input.quota), icon, accent: '#8b7cf6',
      views: 0, claimed: 0, estimatedWalkins: 0, createdAt,
      expiresAt: createdAt + Number(input.expiryHours) * 3600000, active: 1, happyHour: input.template === 'happy' ? 1 : 0 };
    await run(`INSERT INTO deals (id,merchant,category,badge,title,shop,area,code,distance,quota,remaining,icon,accent,views,claimed,estimatedWalkins,createdAt,expiresAt,active,happyHour)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [deal.id,deal.merchant,deal.category,deal.badge,deal.title,deal.shop,deal.area,deal.code,deal.distance,deal.quota,deal.remaining,deal.icon,deal.accent,0,0,0,deal.createdAt,deal.expiresAt,1,deal.happyHour]);
    logger.info('Merchant published a deal', { dealId: id, category });
    res.status(201).json(deal);
  } catch (error) { next(error); }
});

app.get('/api/merchant/summary', async (req, res, next) => {
  try {
    await cleanupExpiredClaims();
    const totals = await get(`SELECT SUM(views) AS totalViews, SUM(claimed) AS claimed,
      SUM(estimatedWalkins) AS walkins, SUM(CASE WHEN active=1 AND expiresAt>? THEN 1 ELSE 0 END) AS active FROM deals`, [Date.now()]);
    const deals = await all('SELECT * FROM deals ORDER BY createdAt DESC LIMIT 12');
    res.json({ totalViews: totals.totalViews || 0, claimed: totals.claimed || 0, walkins: totals.walkins || 0, active: totals.active || 0, deals });
  } catch (error) { next(error); }
});

app.get('/api/claims', async (req, res, next) => {
  try {
    await cleanupExpiredClaims();
    const claims = await all('SELECT * FROM claims ORDER BY claimedAt DESC');
    res.json(claims);
  } catch (error) { next(error); }
});

app.post('/api/happy-hour', async (req, res, next) => {
  try {
    const enabled = Boolean(req.body && req.body.enabled);
    await run(`UPDATE deals SET
      happyHour=?,
      badge=CASE WHEN ?=1 AND happyApplied=0 THEN '30% OFF' ELSE badge END,
      title=CASE WHEN ?=1 AND happyApplied=0 THEN 'Happy Hour: 30% off selected menu' ELSE title END,
      happyApplied=CASE WHEN ?=1 THEN 1 ELSE 0 END
      WHERE active=1 AND category='Dining'`, [enabled?1:0,enabled?1:0,enabled?1:0,enabled?1:0]);
    res.json({ enabled });
  } catch (error) { next(error); }
});

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && 'body' in error) return res.status(400).json({ error: 'Invalid JSON request body.' });
  logger.error('Request failed', { message: error.message, stack: error.stack, path: req.path });
  if (res.headersSent) return next(error);
  res.status(500).json({ error: 'The server could not complete that request. Please try again.' });
});

async function start() {
  try {
    await initializeDatabase();
    const server = app.listen(PORT, () => logger.info('DealDrop server ready', { port: PORT, database: DB_PATH }));
    const shutdown = () => server.close(() => db.close(() => process.exit(0)));
    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  } catch (error) {
    logger.error('Startup failed', { message: error.message, stack: error.stack });
    process.exit(1);
  }
}

if (require.main === module) start();
module.exports = { app, start, initializeDatabase, cleanupExpiredClaims, db };
