const request = require('supertest');
const { app } = require('../server');

describe('DealDrop API contract', () => {
  test('publishes an OpenAPI document', async () => {
    const response = await request(app).get('/api/docs');
    expect(response.status).toBe(200);
    expect(response.body.openapi).toBe('3.0.3');
    expect(response.body.paths['/api/deals']).toBeDefined();
  });

  test('rejects malformed deal JSON with a clear 400 response', async () => {
    const response = await request(app).post('/api/deals').set('Content-Type', 'application/json').send('{bad json');
    expect(response.status).toBe(400);
    expect(response.body.error).toMatch(/Invalid JSON/);
  });
});
