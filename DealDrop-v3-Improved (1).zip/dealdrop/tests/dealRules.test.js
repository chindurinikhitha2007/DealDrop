const { validateDeal, recoverExpiredClaims } = require('../lib/dealRules');

describe('validateDeal', () => {
  const validDeal = { merchant: 'Local Cafe', title: 'Twenty percent off coffee',
    category: 'Dining', quota: 20, expiryHours: 4 };

  test('accepts a valid deal', () => {
    expect(validateDeal(validDeal)).toEqual({ valid: true, errors: [] });
  });

  test('rejects invalid category and quota', () => {
    const result = validateDeal({ ...validDeal, category: 'Unknown', quota: 900 });
    expect(result.valid).toBe(false);
    expect(result.errors.join(' ')).toMatch(/category/);
    expect(result.errors.join(' ')).toMatch(/quota/);
  });

  test('rejects missing business name and short title', () => {
    const result = validateDeal({ ...validDeal, merchant: '', title: 'Hi' });
    expect(result.valid).toBe(false);
  });
});

describe('recoverExpiredClaims', () => {
  test('returns expired held vouchers to quota exactly once', () => {
    const deals = [{ id: 'd1', quota: 5, remaining: 1, claimed: 4 }];
    const claims = [
      { id: 'c1', dealId: 'd1', status: 'held', claimExpiresAt: 100 },
      { id: 'c2', dealId: 'd1', status: 'held', claimExpiresAt: 500 },
      { id: 'c3', dealId: 'd1', status: 'redeemed', claimExpiresAt: 50 }
    ];
    expect(recoverExpiredClaims(claims, deals, 200)).toBe(1);
    expect(deals[0]).toMatchObject({ remaining: 2, claimed: 3 });
    expect(claims[0].status).toBe('expired');
    expect(recoverExpiredClaims(claims, deals, 200)).toBe(0);
  });

  test('does not exceed the original quota', () => {
    const deals = [{ id: 'd1', quota: 2, remaining: 2, claimed: 0 }];
    const claims = [{ id: 'c1', dealId: 'd1', status: 'held', claimExpiresAt: 1 }];
    recoverExpiredClaims(claims, deals, 10);
    expect(deals[0].remaining).toBe(2);
  });
});
