const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'data', 'db.json');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const seed = () => {
  const now = Date.now();
  const rows = [
    ['Artisan Coffee','Dining','40% OFF','40% off artisan coffee & pastries','Brew District','Kompally','COFFEE40',2.4,25,9,'☕','#f3a65b'],
    ['Spice Route Kitchen','Dining','25% OFF','25% off your lunch order','Spice Route','Suchitra','SPICE25',1.8,30,12,'🍛','#ed8064'],
    ['Pizza Corner','Dining','BUY 1 GET 1','Buy one pizza slice, get one free','Pizza Corner','Kompally','PIZZA2X1',3.2,20,7,'🍕','#e87961'],
    ['Green Bowl Cafe','Dining','₹100 OFF','Flat ₹100 off healthy bowls','Green Bowl','Miyapur','BOWL100',4.1,18,8,'🥗','#83b77d'],
    ['Glow Studio','Wellness','25% OFF','25% off salon haircut services','Glow Studio','Suchitra','GLOW25',2.7,20,6,'✂️','#cf8eb5'],
    ['Serenity Spa','Wellness','30% OFF','30% off selected wellness sessions','Serenity Spa','Kompally','SERENE30',4.6,15,5,'🧖','#b99bd8'],
    ['Fresh Face Salon','Wellness','₹150 OFF','Flat ₹150 off your next visit','Fresh Face','Miyapur','FRESH150',1.2,25,10,'💆','#dc9ab4'],
    ['Urban Yoga','Wellness','20% OFF','20% off a beginner yoga session','Urban Yoga','Kompally','YOGA20',2.9,24,11,'🧘','#9bb7a0'],
    ['FitZone Gym','Fitness','1+1 FREE','Bring a friend: 1+1 day pass','FitZone','Suchitra','FIT2PASS',1.6,25,8,'🏋️','#7e9bd0'],
    ['Pulse Fitness','Fitness','30% OFF','30% off a weekly gym pass','Pulse Fitness','Miyapur','PULSE30',3.8,30,14,'💪','#7da8c8'],
    ['Smash Arena','Entertainment','₹200 OFF','Flat ₹200 off badminton court booking','Smash Arena','Kompally','SMASH200',4.5,12,4,'🏸','#e0a65e'],
    ['Movie Nest','Entertainment','20% OFF','20% off weekday movie tickets','Movie Nest','Suchitra','MOVIE20',2.1,40,19,'🎬','#8d8bc9'],
    ['PlayHouse Arcade','Entertainment','15% OFF','15% off arcade game cards','PlayHouse','Miyapur','PLAY15',4.8,35,16,'🕹️','#d49b64'],
    ['QuickClean Dry Cleaners','Services','₹200 OFF','Flat ₹200 off dry cleaning bills','QuickClean','Kompally','CLEAN200',1.9,25,10,'👔','#80a8b4'],
    ['Spark Shoe Care','Services','20% OFF','20% off shoe cleaning and care','Spark Shoe Care','Suchitra','SPARK20',3.5,20,9,'👟','#a8a17a'],
    ['FixIt Electronics','Services','10% OFF','10% off accessory and repair services','FixIt','Miyapur','FIXIT10',4.9,18,6,'🔧','#8c9ba8']
  ];
  return rows.map((r,i)=>({id:'deal-'+(i+1),merchant:r[0],category:r[1],badge:r[2],title:r[3],shop:r[4],area:r[5],code:r[6],distance:r[7],quota:r[8],remaining:r[8]-r[9],icon:r[10],accent:r[11],views:120+i*17,claimed:r[8]-(r[8]-r[9]),estimatedWalkins:Math.max(1,Math.round(r[9]*.65)),createdAt:now,expiresAt:now+(i===0?2:4+i%5)*60*60*1000,active:true, happyHour:false}));
};
function readDB(){ if(!fs.existsSync(DB)){const d={deals:seed(),claims:[]};fs.writeFileSync(DB,JSON.stringify(d,null,2));return d;} return JSON.parse(fs.readFileSync(DB,'utf8')); }
function writeDB(d){fs.writeFileSync(DB,JSON.stringify(d,null,2));}
function cleanup(db){const now=Date.now();let changed=false;db.claims.forEach(c=>{if(c.status==='held'&&c.claimExpiresAt<=now){const deal=db.deals.find(x=>x.id===c.dealId);if(deal){deal.remaining=Math.min(deal.quota,deal.remaining+1);deal.claimed=Math.max(0,deal.claimed-1);}c.status='expired';changed=true;}});if(changed)writeDB(db);}
app.get('/api/deals',(req,res)=>{const db=readDB();cleanup(db);const now=Date.now();res.json({serverNow:now,deals:db.deals.filter(d=>d.active&&d.expiresAt>now)});});
app.post('/api/deals/:id/view',(req,res)=>{const db=readDB();const d=db.deals.find(x=>x.id===req.params.id);if(!d)return res.status(404).json({error:'Deal not found'});d.views++;writeDB(db);res.json({views:d.views});});
app.post('/api/deals/:id/claim',(req,res)=>{const db=readDB();cleanup(db);const d=db.deals.find(x=>x.id===req.params.id);if(!d||!d.active||d.expiresAt<=Date.now())return res.status(404).json({error:'This deal has expired'});if(d.remaining<=0)return res.status(409).json({error:'All vouchers have been claimed'});d.remaining--;d.claimed++;const code=d.code+'-'+crypto.randomBytes(2).toString('hex').toUpperCase();const claim={id:crypto.randomUUID(),dealId:d.id,merchant:d.merchant,code,status:'held',claimedAt:Date.now(),claimExpiresAt:Date.now()+2*60*60*1000};db.claims.push(claim);writeDB(db);res.json({claim,deal:d,serverNow:Date.now()});});
app.post('/api/deals',(req,res)=>{const {merchant,category,badge,title,shop,area,quota,expiryHours,template}=req.body;if(!merchant||!title||!category||!Number(quota)||!Number(expiryHours))return res.status(400).json({error:'Please complete all required fields'});const db=readDB();const code=(merchant.replace(/[^A-Z]/gi,'').slice(0,5).toUpperCase()||'DEAL')+Math.floor(10+Math.random()*90);const d={id:'deal-'+crypto.randomUUID(),merchant,category,badge:badge||'SPECIAL OFFER',title,shop:shop||merchant,area:area||'Kompally',code,distance:2.0,quota:Number(quota),remaining:Number(quota),claimed:0,icon:({Dining:'☕',Wellness:'✂️',Fitness:'🏋️',Entertainment:'🎬',Services:'🛠️'})[category]||'✨',accent:'#8b7cf6',views:0,estimatedWalkins:0,createdAt:Date.now(),expiresAt:Date.now()+Number(expiryHours)*3600000,active:true,happyHour:template==='happy'};db.deals.unshift(d);writeDB(db);res.status(201).json(d);});
app.get('/api/merchant/summary',(req,res)=>{const db=readDB();cleanup(db);const deals=db.deals;res.json({totalViews:deals.reduce((a,d)=>a+d.views,0),claimed:deals.reduce((a,d)=>a+d.claimed,0),walkins:deals.reduce((a,d)=>a+d.estimatedWalkins,0),active:deals.filter(d=>d.active&&d.expiresAt>Date.now()).length,deals:deals.slice(0,12)});});
app.get('/api/claims',(req,res)=>{const db=readDB();cleanup(db);res.json(db.claims.slice().reverse());});
app.post('/api/happy-hour',(req,res)=>{const db=readDB();const {enabled}=req.body;db.deals.forEach(d=>{if(d.active&&d.category==='Dining'){d.happyHour=!!enabled;if(enabled&&!d.happyApplied){d.badge='30% OFF';d.title='Happy Hour: 30% off selected menu';d.happyApplied=true;}else if(!enabled&&d.happyApplied){d.happyHour=false;d.happyApplied=false;}}});writeDB(db);res.json({enabled:!!enabled});});
app.listen(PORT,()=>console.log(`DealDrop running at http://localhost:${PORT}`));
